@extends('layouts.default2')
<br>
@section('content')
<div class="outer-container home-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-md-6 col-lg-3 no-padding">
                <div class="portfolio-content">
                    <figure>
                        <img src="{{ asset('cakes/cake1.jpeg') }}" alt="Birthday Cake">
                    </figure>
                </div>
            </div><!-- .col -->
        </div>
    </div>
</div>
@endsection
